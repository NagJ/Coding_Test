﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;

namespace MorseCodeConverter
{
    /// <summary>
    /// Decodes Morse text to English text
    /// </summary>
    class Program
    {
        static Dictionary<char, string> _morseCodes;

        static void Main(string[] args)
        {
            try
            {
                // Retrieve the file path from Config file and read the text
                string filePath = ConfigurationManager.AppSettings ["FilePath"];
                string fileText = File.ReadAllText(filePath);

                //Create Morse codes dictionary
                MorseConverter();

                //Write final text
                Console.WriteLine("Decoded value : \n" + ConvertText(fileText));
                Console.WriteLine("Press any key to exit .. ");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception !" + ex.ToString());
                Console.WriteLine("Press any key to exit .. ");
                Console.ReadKey();
            }
        }

        #region Public Methods
        /// <summary>
        /// Method to create a Dictionary with the letter or digit to be encoded as the KEY and the Morse code equivalent in the VALUE
        /// </summary>
        public static void MorseConverter()
        {
            try
            {
                _morseCodes = new Dictionary<char, string>();
                _morseCodes.Add('A', ".-");
                _morseCodes.Add('B', "-...");
                _morseCodes.Add('C', "-.-.");
                _morseCodes.Add('D', "-..");
                _morseCodes.Add('E', ".");
                _morseCodes.Add('F', "..-.");
                _morseCodes.Add('G', "--.");
                _morseCodes.Add('H', "....");
                _morseCodes.Add('I', "..");
                _morseCodes.Add('J', ".---");
                _morseCodes.Add('K', "-.-");
                _morseCodes.Add('L', ".-..");
                _morseCodes.Add('M', "--");
                _morseCodes.Add('N', "-.");
                _morseCodes.Add('O', "---");
                _morseCodes.Add('P', ".--.");
                _morseCodes.Add('Q', "--.-");
                _morseCodes.Add('R', ".-.");
                _morseCodes.Add('S', "...");
                _morseCodes.Add('T', "-");
                _morseCodes.Add('U', "..-");
                _morseCodes.Add('V', "...-");
                _morseCodes.Add('W', ".--");
                _morseCodes.Add('X', "-..-");
                _morseCodes.Add('Y', "-.--");
                _morseCodes.Add('Z', "--..");
                _morseCodes.Add('1', ".----");
                _morseCodes.Add('2', "..---");
                _morseCodes.Add('3', "...--");
                _morseCodes.Add('4', "....-");
                _morseCodes.Add('5', ".....");
                _morseCodes.Add('6', "-....");
                _morseCodes.Add('7', "--...");
                _morseCodes.Add('8', "---..");
                _morseCodes.Add('9', "----.");
                _morseCodes.Add('0', "-----");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion Public Methods

        #region Private Methods

        /// <summary>
        /// Decodes the morse code sentence to english sentence
        /// </summary>
        /// <param name="sentence">Input sentence to decode</param>
        /// <returns>Final Value</returns>
        private static string ConvertText(string sentence)
        {
            try
            {
                string[] stringSeparators = new string[] { "||" }; // If || is given for word seperation
                //Split the sentence to a string of words
                string[] words = (sentence.Contains("||") ? sentence.ToUpper().Split(stringSeparators, StringSplitOptions.None) : sentence.ToUpper().Split(' '));
                string replaceWith = string.Empty;
                bool isContains = false;
                string[] replWords = new string[] { "" };
                StringBuilder decdString = new StringBuilder();

                //Iterate through each word in the sentence to find a match
                foreach (string word in words)
                {
                    // Check for the new line 
                    replWords = new string[] { word };

                    if (word.Contains("\r\n") || word.Contains("\r") || word.Contains("\n"))
                    {
                        stringSeparators = GetStringSeperator(word, stringSeparators);
                        replWords = word.Split(stringSeparators, StringSplitOptions.None);
                        isContains = true;
                    }

                    foreach (string replWord in replWords)
                    {
                        switch (replWord)
                        {
                            // If any of the below characters are given for word sepertion, Add a space to final string
                            case "/":
                            case "":
                            case "|":
                                decdString.Append(" ");
                                break;
                            default:
                                {
                                    //Iterate Dictionary values to find a match
                                    foreach (KeyValuePair<Char, String> MorseItem in _morseCodes)
                                    {
                                        if (MorseItem.Value == replWord)
                                        {
                                            decdString.Append(MorseItem.Key.ToString());
                                            break;
                                        }
                                    }
                                    if (isContains)
                                    {
                                        decdString.Append(Environment.NewLine);
                                        isContains = false;
                                    }
                                }
                                break;
                        }
                    }
                }
                // Return the final string
                return decdString.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Builds the string seperator for adding new line to final text
        /// </summary>
        /// <param name="word">Input Text</param>
        /// <returns>StringSeperator</returns>
        private static string[] GetStringSeperator(string word, string[] stringSeparators)
        {
            try
            {
                if (word.Contains("\r\n"))
                    stringSeparators = new string[] { "\r\n" };
                else if (word.Contains("\r"))
                    stringSeparators = new string[] { "\r" };
                else if (word.Contains("\n"))
                    stringSeparators = new string[] { "\n" };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stringSeparators;
        }
    }
    #endregion Private Methods
}
